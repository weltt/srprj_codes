 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\EMA\ExportFolder\0\165381\Output\Eagle\Eagle\Eagle.xml
 
 
To import your new library into Eagle:
1. Start Eagle.
2. In the control panel window, Select File -> New -> Library from the menu.
3. In the blank library window, select File -> Execute Script from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
7. Use File -> Save (or Save As..) to save the library to the desired location in Eagle native format.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q
 
 


Ultra Librarian Gold 8.2.139 Process Report


Message - PadStack "EX22Y59p71D0T" Shape(1) has no shape.
Message - PadStack "EX22Y59p71D0T" Shape(2) has no shape.
Message - PadStack "EX22Y59p71D0T" Shape(3) has no shape.
Message - Padstack "EX22Y59p71D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX20Y40D0T" Shape(4) is a CIRCLE with no diameter.
Message - PadStack "EX24Y71p71D0T" Shape(1) has no shape.
Message - PadStack "EX24Y71p71D0T" Shape(2) has no shape.
Message - PadStack "EX24Y71p71D0T" Shape(3) has no shape.
Message - Padstack "EX24Y71p71D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX24Y64D0T" Shape(4) is a CIRCLE with no diameter.
Message - PadStack "EX20Y47p71D0T" Shape(1) has no shape.
Message - PadStack "EX20Y47p71D0T" Shape(2) has no shape.
Message - PadStack "EX20Y47p71D0T" Shape(3) has no shape.
Message - Padstack "EX20Y47p71D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX22Y52D0T" Shape(4) is a CIRCLE with no diameter.

TextStyle count:  24
Padstack count:   6
Pattern count:    3
Symbol count:     1
Component count:  1

Export


